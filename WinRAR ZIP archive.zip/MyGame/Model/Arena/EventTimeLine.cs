﻿using Microsoft.Xna.Framework;

namespace MyGame.Model.Arena
{
    public class EventTimeline
    {
        public void Update(GameTime gameTime)
        {
        }
    }
}
